from dash import dcc, html
import pandas as pd

# Assuming team_data.csv is in the same directory as your script
team_data_csv = 'team_data.csv'

def generate_description_card():
    """
    :return: A Div containing dashboard title & descriptions.
    """
    return html.Div(
        id="description-card",
        children=[
            html.H5("Select a Team:"),
        ],
    )

def generate_control_card():
    """
    :return: A Div containing controls for graphs.
    """
    # Load team data to get the list of teams
    team_data = pd.read_csv(team_data_csv)
    teams = team_data['team'].unique()

    return html.Div(
        id="control-card",
        children=[
            dcc.Dropdown(
                id='team-selector',
                options=[{'label': team, 'value': team} for team in teams],
                value=teams[0]  # Set the default value to the first team
            ),
            html.Button('Select', id='select-team-button'),
        ], style={"textAlign": "float-left"}
    )

def make_menu_layout():
    return [generate_description_card(), generate_control_card()]
