
import pandas as pd
import plotly.express as px

def load_team_data(csv_file_path):
    return pd.read_csv(csv_file_path)

def load_player_data(csv_file_path):
    return pd.read_csv(csv_file_path)

def top_scoring_teams(team_data):
    # Sorting and selecting top 10 teams based on goals
    top_teams = team_data.sort_values(by='goals', ascending=False).head(10)
    return px.bar(top_teams, x='team', y='goals', title='Top 10 Scoring Teams')

def best_defensive_teams(team_data):
    # Sorting and selecting top 10 teams based on goalkeeper clean sheets
    top_defensive_teams = team_data.sort_values(by='gk_clean_sheets', ascending=False).head(10)
    return px.bar(top_defensive_teams, x='team', y='gk_clean_sheets', title='Top 10 Defensive Teams')

def top_scoring_players(player_data):
    # Sorting and selecting top 10 players based on goals
    top_players = player_data.sort_values(by='goals', ascending=False).head(10)
    return px.bar(top_players, x='player', y='goals', title='Top 10 Scoring Players')
