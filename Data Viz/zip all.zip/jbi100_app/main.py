from dash import Dash


app = Dash(__name__)
app.title = "JBI100 Template"
